# Novidades — BLACK Reloaded Mod para o port de BLACK (Spark198)

## 1.9

**Corpo da terceira pessoa**
- Vitrine do personagem: em MODS > CORPO DO JOGADOR, o personagem escolhido gira numa vitrine ao lado das opções.
- Linha SKIN: para a maioria dos soldados, a roupa de cada missão em que ele aparece (AUTO usa a da missão atual).
- Os 7 modelos de inimigo agora são só o visual por cima do esqueleto do aliado: todos miram, andam e viram do mesmo
  jeito, sem os comportamentos próprios de cada inimigo (olhar para o lado, corpo fora da mira).
- Nenhum modelo carrega escudo na mão (o escudo do soldado de escudo e o de acrílico do soldado LMG).
- O rosto de cada pose fica certo para cada família de armas.
- A câmera livre não mexe mais o corpo: ele fica congelado enquanto a câmera olha em volta.
- Só tocam os passos do personagem à vista: os do corpo na terceira pessoa, os do jogador na primeira.
- A animação de corrida do corpo fica 1,3× mais rápida (`[sprint] animation`).
- Pose de pistola também nos modelos de inimigo.

**Seventh Wave**
- A aniquilação pede um mínimo fixo de inimigos abatidos por missão: Veblensk 120, Treneska 240, Cidade Nazran 250,
  Fundição Nazran 300, Tivliz 270, Vratska 260, Ponte Graznei 220, Spetriniv 360. Passar do mínimo não o aumenta.
- Os textos do objetivo trazem o número ("Completar os Primários e Eliminar 360 Inimigos"), e o painel, a pausa e
  os resultados mostram abatidos/mínimo. O painel fica sempre em branco.
- As cópias do 2× esperam até 45 s por um lugar para nascer (5 s fora da Seventh Wave).
- Sair da missão pelo menu de pausa termina a partida nos menus (antes, SEVENTH WAVE aparecia duas vezes na escolha
  de dificuldade).

**Outros**
- Trapaça nova: FÔLEGO INFINITO (MODS > TRAPAÇAS > MAIS).
- A mira da P90 e das armas sem pose de mira moderna continua na tela ao mirar.
- As cópias dos soldados de RPG nascem a 4 m do original, para um não travar o tiro do outro.
- O `black_mods.log` registra onde o jogador começa cada fase e a que distância fica o ponto de spawn de inimigo
  mais perto; os logs das três sessões anteriores ficam em `black_mods_anterior1..3.log`.

**Correções**
- Com a M16A2 de ouro na primeira pessoa, os braços também ficavam dourados (a textura dos braços vem no arquivo
  dessa arma): agora só a arma fica de ouro e os braços ficam com a cor normal.
- No modo desafio, a M16A2 prateada (ou dourada) do prêmio da Black Ops tomava o lugar da arma do desafio: agora o
  desafio sempre usa a escolhida.
- Travamento do jogo no teste de colisão quando dois volumes redondos (personagens, corpos) ficam exatamente no
  mesmo ponto: os dois agora são afastados.
- Travamento em checkpoints com o corpo da terceira pessoa (busca de animação sem árvore de animações).
- O estado de cada fase (o corpo, a fila de cópias do multiplicador) recomeça em toda carga, checkpoint e
  REINICIAR A MISSÃO; antes, um corpo da fase anterior podia comandar um inimigo da fase nova.

## 1.8

- O mod passa a se chamar BLACK Reloaded Mod (os arquivos continuam com o prefixo `black_mods`).
- Dano de queda: nada até 3 m, mata a partir de 12 m (as duas alturas ajustáveis).
- Textos dos menus no dobro da velocidade.
- Rodapé "Reloaded Mod © 2026 Kromer" no menu principal.

## 1.7

- Primeira versão distribuída: 27 mods, página MODS, modo desafio, speedrun, Black Ops com ou sem mods, Seventh Wave,
  armas de ouro e PC SETTINGS em português.

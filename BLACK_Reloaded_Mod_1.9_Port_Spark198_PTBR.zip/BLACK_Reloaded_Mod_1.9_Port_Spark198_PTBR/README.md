# BLACK Reloaded Mod 1.9 — port de PC (Spark198), PT-BR

29 mods para BLACK (Criterion, 2006) numa única `winmm.dll`, feitos para o **port de PC de BLACK (Spark198, versão
0.2.0)** com a tradução em português: pulo, corrida, noclip, dano de queda, câmera livre, terceira pessoa com corpo,
mira moderna, trapaças, armas de ouro, multiplicador de inimigos, modo esquadrão, o **modo desafio** que foi cortado do
jogo, speedrun, a dificuldade **Seventh Wave** e uma página **MODS** dentro do menu de pausa, onde quase tudo liga,
desliga e se ajusta durante a partida.

> Existe também uma versão em inglês para o XBE Recomp de BLACK, publicada à parte.

![Vitrine do personagem na página MODS](imagens/vitrine.jpg)

## Instalar

1. Tenha o port de BLACK 0.2.0 (`black.exe` e `blackrt.dll`) funcionando com a sua cópia do jogo (disco NTSC-U do
   Xbox, com a tradução PT-BR).
2. Copie a `winmm.dll` para a pasta onde está o `black.exe`:

   ```
   BLACK\
     game\          (os arquivos do disco)
     port\
       black.exe
       blackrt.dll
       winmm.dll    <- o mod
   ```

3. Abra o jogo pelo `black.exe`. Na primeira vez, o mod cria o `black_mods.ini` (as opções) e monta as telas dele a
   partir dos arquivos do seu jogo. O **MODO DESAFIO** aparece no menu principal e **MODS** no menu de pausa.

Para atualizar, troque só a `winmm.dll`: as opções e o progresso continuam. Para remover, apague a `winmm.dll`
(e, se quiser, os arquivos `black_mods*` e as pastas `black_mods_menus` e `black_mods_ouro`).

O mod não traz nenhum arquivo do jogo: as telas, os textos corrigidos e as texturas douradas são feitos na hora, a
partir da sua própria cópia.

## Teclas

| Tecla | O que faz |
|---|---|
| `C` | pular |
| `LCtrl` (segurar) | correr |
| `F1` | câmera livre |
| `F2` | esconder e mostrar o HUD |
| `F3` | primeira pessoa → terceira pessoa → sobre o ombro |
| `F4` | noclip |

Todas as teclas e opções mudam em MODS, no menu de pausa, ou no `black_mods.ini`.

## Os mods

A lista completa, com o que cada um faz, está em [`LISTA-DE-MODS.html`](LISTA-DE-MODS.html).

- **Movimento:** pulo, corrida com fôlego, noclip e dano de queda.
- **Câmera e visual:** câmera livre, tecla do HUD, terceira pessoa (atrás e sobre o ombro), corpo do jogador com
  10 personagens, skins por missão e vitrine na página MODS, mira moderna pela alça de mira, sem o filtro amarelo e
  sem o desfoque da recarga.
- **Armas e combate:** escolha da animação de recarga, trapaças, armas de prata, armas de ouro (com o dobro de dano)
  e a M16A2 prateada.
- **Inimigos e aliados:** multiplicador de inimigos (1× a 3×) e modo esquadrão com 1 ou 2 aliados.
- **Modos e dificuldades:** modo desafio (Hora de matar e Contagem de cabeças, com medalhas e recordes), speedrun,
  Black Ops com ou sem mods e a Seventh Wave.
- **Interface e tradução:** página MODS, PC SETTINGS em português, correções de texto, ajustes dos menus e textos dos
  menus mais rápidos.

![Terceira pessoa com o corpo do jogador](imagens/terceira_pessoa.jpg)

### Seventh Wave

A quinta dificuldade, liberada pelas 8 missões da Black Ops sem mods: o dobro de inimigos, 2% de chance de cura por
inimigo, nenhum pacote de saúde e o objetivo de **aniquilação** no lugar do de destruição, com um mínimo de inimigos
abatidos por missão (Veblensk 120, Treneska 240, Cidade Nazran 250, Fundição Nazran 300, Tivliz 270, Vratska 260,
Ponte Graznei 220, Spetriniv 360).

![Carga da Seventh Wave](imagens/seventh_wave_carga.jpg)
![Estado dos objetivos na Seventh Wave](imagens/seventh_wave_objetivos.jpg)

### Prêmios

| Etapa | Como | Libera |
|---|---|---|
| 1 | 8 missões na Black Ops sem mods | a M16A2 prateada e a dificuldade Seventh Wave |
| 2 | 8 missões na Seventh Wave sem mods | as armas de ouro e as trapaças |

Uma missão conta quando é jogada do começo ao fim sem mods (a resposta JOGAR SEM MODS) e com os objetivos necessários
cumpridos.

![Mira moderna](imagens/mira_moderna.jpg)
![Modo desafio](imagens/modo_desafio.jpg)

## Novidades

Veja [`CHANGELOG.md`](CHANGELOG.md). Na 1.9: vitrine do personagem e escolha de skin, modelos de inimigo só como visual
(sem escudo), corpo parado na câmera livre, passos só do personagem à vista, fôlego infinito, o mínimo de abates da
Seventh Wave e correções de travamentos do jogo.

## Problemas

O `black_mods.log`, ao lado da `winmm.dll`, mostra o que cada mod fez; com outra versão do jogo ou do port, ele avisa
o que ficou desligado. Os logs das três sessões anteriores ficam em `black_mods_anterior1..3.log`, e o log do port de
uma partida que fechou com erro fica em `black_falha_anterior.log`.

## Direitos

© 2026 Kromer. Todos os direitos reservados. O código do mod é fechado: só a `winmm.dll` é distribuída. Você pode usar
o mod e compartilhar este pacote de graça, sem alterações; não é permitido vender o mod nem distribuir versões
modificadas da `winmm.dll`. Veja [`LICENSE.txt`](LICENSE.txt).

BLACK é da Criterion Games e da Electronic Arts; o port de PC é de Spark198. Este é um projeto de fãs, sem ligação com
eles. É preciso ter a sua própria cópia do jogo.

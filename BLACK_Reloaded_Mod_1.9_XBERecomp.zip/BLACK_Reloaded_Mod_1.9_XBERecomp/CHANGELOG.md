# Changelog — BLACK Reloaded Mod for the XBE Recomp of BLACK

## 1.9

**Third-person body**
- Character display: on MODS > PLAYER BODY the chosen character turns on a display beside the options.
- SKIN row: for most soldiers, the outfit of each mission he appears in (AUTO uses the current mission's).
- The 7 enemy models are now only a look drawn over the ally's skeleton: they all aim, walk and turn the same way,
  without the enemies' own behaviour (looking aside, body off the crosshair).
- No model holds a shield (the riot shield soldier's and the LMG soldier's plexi shield).
- The face of each pose is right for each weapon family.
- The free camera no longer moves the body: it stays frozen while the camera looks around.
- Only the footsteps of the character in view play: the body's in third person, the player's in first person.
- The body's running animation plays 1.3× faster (`[sprint] animation`).
- Pistol pose on the enemy models too.

**Seventh Wave**
- The annihilation asks for a fixed minimum of fallen enemies per mission: Veblensk 120, Treneska 240, Nazran Town
  250, Nazran Foundry 300, Tivliz 270, Vratska 260, Graznei 220, Spetriniv 360. Killing more never raises it.
- The objective's texts carry the number ("Complete All Primary Objectives and Kill 360 Enemies"), and the panel, the
  pause menu and the results show fallen/minimum. The panel always stays white.
- The 2× copies wait up to 45 s for a free spot (5 s outside the Seventh Wave).

**Other**
- New cheat: INFINITE STAMINA (MODS > CHEATS > MORE).
- The P90's crosshair, and that of every weapon without a modern-aim pose, stays on screen when aiming.
- The copies of RPG soldiers spawn 4 m from the original, so one does not block the other's shots.
- The gold weapons' firing sound is no longer distorted (the gold tint no longer touches the sound banks).
- `black_mods.log` records where the player starts each level and how far the nearest enemy spawn point is; the
  last three sessions' logs are kept as `black_mods_previous1..3.log`.

**Fixes**
- With the gold M16A2 in first person, the arms were tinted gold too (the arms' texture comes in that weapon's file):
  now only the weapon turns gold and the arms keep their colour.
- In the challenge mode, the silver (or gold) M16A2 of the Black Ops reward took the place of the challenge's weapon:
  now the challenge always uses the chosen one.
- A crash at checkpoints with the third-person body (an animation lookup without an animation tree).
- The state of each level (the body, the multiplier's queue of copies) starts over on every load, checkpoint and
  RESTART MISSION. The recomp keeps the player in the same character slot on every level, so before this a body left
  from the previous level could drive an enemy of the new one (enemies idle at the start until the game restarted).

## 1.8

- First release for the XBE Recomp, in English: every mod of the PC port version, a clean sound mode (proper
  resampling, reverb filter, limiter, 50% volume, F9 capture), the MODS page rebuilt for the recomp.
- Fixes of the game: a crash in the collision test when two round volumes end up on exactly the same point; leaving a
  Seventh Wave mission through the pause menu left SEVENTH WAVE twice on the difficulty page.

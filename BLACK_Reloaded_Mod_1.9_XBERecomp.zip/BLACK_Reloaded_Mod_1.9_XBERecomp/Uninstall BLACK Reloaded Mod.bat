@echo off
rem BLACK Reloaded Mod - uninstall for the XBE Recomp. Run it with the game closed, from the folder of BLACK.exe.
cd /d "%~dp0"
if not exist "BLACK.exe" (
    echo This file must be in the BLACK XBERecomp folder, next to BLACK.exe.
    pause
    exit /b 1
)
tasklist /FI "IMAGENAME eq BLACK.exe" | find /I "BLACK.exe" >nul && (
    echo Close the game first.
    pause
    exit /b 1
)
if exist "compiler\config\game.toml.original" (
    copy /Y "compiler\config\game.toml.original" "compiler\config\game.toml" >nul
    del "compiler\config\game.toml.original"
    echo Restored compiler\config\game.toml
)
if exist "compiler\BLACK_original.lib" (
    copy /Y "compiler\BLACK_original.lib" "compiler\BLACK.lib" >nul
    del "compiler\BLACK_original.lib"
    echo Restored compiler\BLACK.lib
)
if exist "compiler\reloaded_mod.lib" del "compiler\reloaded_mod.lib"
if exist "winmm.dll" del "winmm.dll"
if exist "Black.dll" del "Black.dll"
if exist "compiler\work\Black\built.txt" del "compiler\work\Black\built.txt"
echo.
echo BLACK Reloaded Mod removed. The recomp compiles the original game on the next start.
echo Your options, progress and records (black_mods_*.ini/.dat) were kept; delete them if you want.
pause

# BLACK Reloaded Mod 1.9 — XBE Recomp

24 mods for BLACK (Criterion, 2006) in a single `winmm.dll`, made for the **XBE Recomp of BLACK**: jump, sprint,
noclip, fall damage, free camera, third person with a body, modern aim, clean sound, cheats, gold weapons, enemy
multiplier, squad mode, the **challenge mode** that was cut from the game, speedrun, the **Seventh Wave** difficulty and
a **MODS** page inside the pause menu, where almost everything turns on, off and is adjusted while you play.

> There is also a Brazilian Portuguese version for the PC port of BLACK (Spark198), published separately.

![The character display on the MODS page](images/character_display.jpg)

## Install

1. Have the XBE Recomp of BLACK working with your copy of the game (`BLACK.exe`, the `compiler` folder and the NTSC-U
   disc image in the `assets` folder).
2. Copy `winmm.dll` into the folder where `BLACK.exe` is:

   ```
   BLACK XBERecomp\
     assets\          (the disc image)
     compiler\
     hdd\
     BLACK.exe
     winmm.dll        <- the mod
   ```

3. Start the game with `BLACK.exe`. The first time, the mod adds its hooks to the recomp's build and the recomp
   compiles the game again. When it asks "The game is ready. Start the game now?", leave **Delete the compiler
   files** unticked: the mod needs the compiler to install itself. **CHALLENGE MODE** shows up on the main menu and
   **MODS** on the pause menu.

To update, just swap `winmm.dll`: the options, the progress and the records stay. To remove it, close the game and run
`Uninstall BLACK Reloaded Mod.bat` from the folder of `BLACK.exe`; do not just delete `winmm.dll`, because the game the
recomp compiled with the mod needs it to start.

The mod ships no game file: its menu pages and the gold textures are made on the spot from your own disc image.

## Keys

| Key | What it does |
|---|---|
| `C` | jump |
| `LCtrl` (hold) | sprint |
| `F1` | free camera |
| `F2` | hide and show the HUD |
| `F3` | first person → third person → over the shoulder |
| `F4` | noclip |
| `F9` | save the last 30 seconds of sound |

Every key and option can be changed in MODS, on the pause menu, or in `black_mods.ini`.

## The mods

The full list, with what each one does, is in [`MOD-LIST.html`](MOD-LIST.html); install notes and troubleshooting are
in [`README.txt`](README.txt).

- **Movement:** jump, sprint with stamina, noclip and fall damage.
- **Camera and visuals:** free camera, HUD key, third person (behind and over the shoulder), the player body with 10
  characters, per-mission skins and a display on the MODS page, modern aim down the sights, no yellow filter.
- **Weapons and combat:** reload animation choice, cheats, silver weapons, gold weapons (with double damage) and the
  silver M16A2.
- **Enemies and allies:** enemy multiplier (1× to 3×) and squad mode with 1 or 2 allies.
- **Modes and difficulties:** challenge mode (Killing Time and Head Count, with medals and records), speedrun, Black
  Ops with or without mods and the Seventh Wave.
- **Sound:** clean sound (proper resampling, filtered reverb, a limiter, a sane volume).
- **Interface:** the MODS page and the mod log.

![Third person with the player body and the squad](images/third_person_squad.jpg)

### Seventh Wave

The fifth difficulty, unlocked by the 8 Black Ops missions without mods: twice the enemies, a 2% chance of health per
enemy, no healthpacks and the **annihilation** objective instead of the destruction one, with a minimum of fallen
enemies per mission (Veblensk 120, Treneska 240, Nazran Town 250, Nazran Foundry 300, Tivliz 270, Vratska 260,
Graznei 220, Spetriniv 360).

![The annihilation panel](images/seventh_wave_panel.jpg)
![The Seventh Wave results](images/seventh_wave_results.jpg)

### Rewards

| Stage | How | Unlocks |
|---|---|---|
| 1 | 8 missions on Black Ops without mods | the silver M16A2 and the Seventh Wave difficulty |
| 2 | 8 missions on the Seventh Wave without mods | the gold weapons and the cheats |

A mission counts when it is played from start to finish without mods (the PLAY WITHOUT MODS answer) and with the
required objectives met.

## What's new

See [`CHANGELOG.md`](CHANGELOG.md). In 1.9: the character display and skin choice, enemy models as a look only (no
shield), the body frozen during the free camera, footsteps only from the character in view, infinite stamina, the
Seventh Wave's annihilation minimum and fixes for crashes and for enemies idle at the start of a level.

## Troubleshooting

`black_mods.log`, next to `winmm.dll`, shows what each mod did; with another version of the game or of the recomp, it
says what stayed off. The last three sessions' logs are kept as `black_mods_previous1..3.log`.

## Rights

(c) 2026 Kromer. All rights reserved. The mod's code is closed: only `winmm.dll` is distributed. You may use the mod
and share this package for free, unchanged; selling the mod or distributing modified versions of `winmm.dll` is not
allowed. See [`LICENSE.txt`](LICENSE.txt).

BLACK belongs to Criterion Games and Electronic Arts. This is a fan project with no ties to them. You need your own
copy of the game.

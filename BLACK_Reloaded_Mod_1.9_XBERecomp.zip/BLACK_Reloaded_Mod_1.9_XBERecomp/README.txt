BLACK Reloaded Mod 1.9 - mods for the XBE Recomp of BLACK
=========================================================

24 mods in a single DLL (winmm.dll): jump, sprint, noclip, fall damage, free camera, HUD key,
third person with a body (10 characters, skins and a display), modern aim, yellow filter, clean sound, reload speed, cheats, silver
weapons, gold weapons, silver M16A2, enemy multiplier, squad mode, challenge mode, speedrun,
Black Ops with or without mods, the Seventh Wave difficulty and a MODS page on the pause menu.
The full list, with what each one does, is in MOD-LIST.html.


REQUIREMENTS

- The XBE Recomp of BLACK working with your copy of the game (BLACK.exe, the compiler folder
  and the NTSC-U disc image in the assets folder).

The mod ships no game file. Its menu pages and the gold textures are made on the spot from
your own disc image.


INSTALL

1. Copy winmm.dll from this package into the folder where BLACK.exe is:

       BLACK XBERecomp\
         assets\          (the disc image)
         compiler\
         hdd\
         BLACK.exe
         winmm.dll        <- the mod

2. Start the game with BLACK.exe, as usual.

The first time, the mod adds its hooks to the recomp's build and the recomp compiles the game
again (it takes a moment). When the recomp asks "The game is ready. Start the game now?", leave
"Delete the compiler files" UNTICKED: the mod needs the compiler to install itself.

CHALLENGE MODE shows up on the main menu and MODS on the pause menu. The mod creates
black_mods.ini (the options) and builds its pages in hdd\E\TDATA\45410083\ReloadedMod.

Updating from an earlier build: just swap winmm.dll. If the new one has other hooks, the game
compiles again on the next start. black_mods.ini, the progress and the records stay; new
options start at their defaults.


KEYS

  C            jump
  LCtrl        sprint (hold)
  F1           free camera
  F2           hide and show the HUD
  F3           first person -> third person -> over the shoulder
  F4           noclip
  F9           saves the last 30 seconds of sound (black_mods_sound_<date>.wav)

The keys and every option can be changed in MODS, on the pause menu, or in black_mods.ini
(the sound options only there, in [audio]). On a key row, confirm and press the key to use
(Esc gives up); left and right also go through the list.
The recomp's own settings (field of view, reload blur, menu animations...) stay under
OPTIONS > RECOMP SETTINGS.

SOUND THAT SEEMS BLOWN OUT
The game mixes very loud: about -10 LUFS in firefights, louder than YouTube (-14) and 6 to
13 dB over other games, so at the Windows volume set for everything else it overdrives
headphones. The mod plays it at 50% (volume = 50 in [audio] of black_mods.ini, about
-16 LUFS); 100 is the game's own level. Windows can still change the sound after the mod: its
enhancements on the output device (Sound > Playback > the device > Properties > Enhancements)
apply to every program, and Bass Boost there makes the lows of the shots and explosions much
louder still. black_mods.log says on each start whether the device has Bass Boost or Loudness
Equalization on. F9 right after a moment that sounds wrong saves what the game sent.


WHAT'S NEW IN 1.9

- Character display: on MODS > PLAYER BODY the chosen character turns beside the options,
  and the new SKIN row picks his outfit among the missions he appears in.
- The enemy models on the third-person body are now only a look over the ally: they all
  aim, walk and turn the same way, and none of them holds a shield.
- The free camera no longer moves the third-person body.
- Only the footsteps of the character in view play (the body in third person, the player
  in first person), and the body's running animation is 1.3x faster.
- New cheat: INFINITE STAMINA (MODS > CHEATS > MORE).
- Seventh Wave: the annihilation asks for a minimum of enemies per mission (Veblensk 120,
  Treneska 240, Nazran Town 250, Nazran Foundry 300, Tivliz 270, Vratska 260, Graznei 220,
  Spetriniv 360), shown as fallen/minimum on the panel, the pause menu and the results.
- The P90's crosshair (and that of every weapon without a modern-aim pose) stays on screen
  when aiming.
- The copies of RPG soldiers spawn farther from the original.
- The weapon sound of the gold weapons is no longer distorted.
- With the gold M16A2 in first person, only the weapon is gold: the arms keep their colour.
- In the challenge mode, the silver M16A2 of the Black Ops reward no longer takes the place of
  the challenge's weapon.
- Fixes: a crash at checkpoints with the third-person body; the state of each level (the
  body, the copies) now starts over on every load and on RESTART MISSION (before, enemies
  of the next level could stand idle at the start); the last three sessions' logs are kept
  as black_mods_previous1..3.log.


FIXES OF THE GAME

- A crash in the game's collision test when two round volumes (characters, bodies) end up on
  exactly the same point, which the extra enemies of the multiplier and of the Seventh Wave make
  possible: the two are now pushed apart instead.
- Leaving a Seventh Wave mission through the pause menu left the difficulty page showing SEVENTH
  WAVE twice (also in place of BLACK OPS) until the next mission: the run now ends on the menus.


REWARDS

- 8 missions on Black Ops without mods (the PLAY WITHOUT MODS answer) unlock the silver
  M16A2 and the Seventh Wave difficulty.
- 8 missions on the Seventh Wave without mods unlock the gold weapons and the cheats.

A mission counts when it is played from start to finish without mods and with the required
objectives met. The progress is kept in black_mods_gold.dat.


UNINSTALL

With the game closed, run "Uninstall BLACK Reloaded Mod.bat" from this package inside the
BLACK XBERecomp folder (next to BLACK.exe). It puts back the recomp's original build files
(compiler\config\game.toml and compiler\BLACK.lib), deletes winmm.dll and Black.dll, and the
recomp compiles the original game on the next start.

Do not just delete winmm.dll: the game the recomp compiled with the mod needs it to start.

Optionally, also delete black_mods.ini, the black_mods*.log files, black_mods_gold.dat,
black_mods_challenges.ini and the hdd\E\TDATA\45410083\ReloadedMod folder.


TROUBLESHOOTING

- black_mods.log, next to winmm.dll, shows what each mod did. With another version of the
  game or of the recomp, it says what stayed off. The last three sessions' logs are kept as
  black_mods_previous1..3.log.
- If the recomp's compiler folder is gone, the mod cannot install itself: reinstall the
  recomp and copy winmm.dll again.


RIGHTS

(c) 2026 Kromer. All rights reserved. You may use the mod and share this zip for free,
unchanged. Selling the mod or distributing modified versions of winmm.dll is not allowed.

BLACK belongs to Criterion Games and Electronic Arts; this is a fan project with no ties to
them. You need your own copy of the game.
